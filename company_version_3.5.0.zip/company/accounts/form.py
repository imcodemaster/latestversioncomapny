from django.contrib.auth.forms import UserCreationForm 
from django import forms
from django.forms import ModelForm
from django.db import transaction
from .models import User,Salesexecutive , Abm , Zbm , Rbm


class SESignUpForm(UserCreationForm):
    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    mobile_number = forms.CharField(required=True)
    email = forms.EmailField(required=True)
    location = forms.CharField(required=True)
    birthdate = forms.CharField()
    gender = forms.CharField()
    height = forms.CharField()
    weight = forms.CharField()
    identification_mark = forms.CharField()
    blood_group = forms.CharField()
    marriage = forms.CharField()
    marriage_date = forms.CharField()
    nation = forms.CharField()


    class Meta(UserCreationForm.Meta):
        model = User
    
    @transaction.atomic
    def save(self):
        user = super().save(commit=False)
        user.is_se = True
        user.first_name = self.cleaned_data.get('first_name')
        user.last_name = self.cleaned_data.get('last_name')
        user.mobile_number=self.cleaned_data.get('mobile_number')
        user.email = self.cleaned_data.get('email')
        user.save()
        se = Salesexecutive.objects.create(user=user)
        
        se.location = self.cleaned_data.get('location')
        se.birthdate = self.cleaned_data.get('birthdate')
        se.birthdate_cert = self.cleaned_data.get('birthdate_cert')
        se.gender = self.cleaned_data.get('gender')
        se.height = self.cleaned_data.get('height')
        se.weight = self.cleaned_data.get('weight')
        se.identification_mark = self.cleaned_data.get('identification_mark')
        se.blood_group = self.cleaned_data.get('blood_group')
        se.marriage = self.cleaned_data.get('marriage')
        se.marriage_date = self.cleaned_data.get('marriage_date')
        se.nation = self.cleaned_data.get('nation')
        se.save()
        return user

class ABMSignUpForm(UserCreationForm):
    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    mobile_number = forms.CharField(required=True)
    email = forms.EmailField(required=True)
    area = forms.CharField(required=True)

    class Meta(UserCreationForm.Meta):
        model = User

    @transaction.atomic
    def save(self):
        user = super().save(commit=False)
        user.is_abm = True
        user.is_staff = False
        user.first_name = self.cleaned_data.get('first_name')
        user.last_name = self.cleaned_data.get('last_name')
        user.mobile_number = self.cleaned_data.get('mobile_number')
        user.email=self.cleaned_data.get('email')
        user.save()
        abm = Abm.objects.create(user=user)
        
        abm.area = self.cleaned_data.get('area')
        abm.save()
        return user

class ZBMSignUpForm(UserCreationForm):
    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    mobile_number = forms.CharField(required=True)
    email = forms.EmailField(required=True)
    zone = forms.CharField(required=True)

    class Meta(UserCreationForm.Meta):
        model = User
    
    @transaction.atomic
    def save(self):
        user = super().save(commit=False)
        user.is_zbm = True
        user.is_staff = True
        user.first_name = self.cleaned_data.get('first_name')
        user.last_name = self.cleaned_data.get('last_name')
        user.mobile_number=self.cleaned_data.get('mobile_number')
        user.email = self.cleaned_data.get('email')
        user.save()
        zbm = Zbm.objects.create(user=user)
        
        zbm.zone = self.cleaned_data.get('zone')
        zbm.save()
        return user


class RBMSignUpForm(UserCreationForm):
    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    email = forms.EmailField(required=True)
    mobile_number = forms.CharField(required=True)
    region = forms.CharField(required=True)

    class Meta(UserCreationForm.Meta):
        model = User

    @transaction.atomic
    def save(self):
        user = super().save(commit=False)
        user.is_rbm = True
        user.is_staff = False
        user.first_name = self.cleaned_data.get('first_name')
        user.last_name = self.cleaned_data.get('last_name')
        user.mobile_number=self.cleaned_data.get('mobile_number')
        user.email=self.cleaned_data.get('email')
        user.save()
        rbm = Rbm.objects.create(user=user)
        rbm.region = self.cleaned_data.get('region')
        rbm.save()
        return user
"""

class ProfileForm(UserCreationForm):
    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    email = forms.EmailField(required=True)
    mobile_number = forms.CharField(required=True)
    image = forms.ImageField()
    info = forms.CharField()

    class Meta(UserCreationForm.Meta):
        model = Profile

    @transaction.atomic
    def save(self):
        user = super().save(commit=False)
        user.first_name = self.cleaned_data.get('first_name')
        user.last_name = self.cleaned_data.get('last_name')
        user.mobile_number=self.cleaned_data.get('mobile_number')
        user.email=self.cleaned_data.get('email')
        user.save()

        profile = Profile.objects.create(user=user)
        profile.image = self.cleaned_data.get('image')
        profile.info = self.cleaned_data.get('info')
        profile.save()
        return user

"""