
from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
	is_se = models.BooleanField(default = False)
	is_abm = models.BooleanField(default = False)
	is_rbm = models.BooleanField(default = False)
	is_zbm = models.BooleanField(default = False)
	is_admin = models.BooleanField(default = False)
	first_name = models.CharField(max_length = 15)
	last_name = models.CharField(max_length = 15)
	email = models.EmailField()
	mobile_number = models.CharField(max_length = 15)


class Salesexecutive(models.Model):
	user = models.OneToOneField(User , on_delete = models.CASCADE , primary_key = True)	
	location = models.CharField(max_length = 15 , null = True , blank = True)
	birthdate = models.CharField(max_length = 15 , null = True , blank = True)
	gender = models.CharField(max_length = 5)
	height = models.CharField(max_length = 5 , null = True , blank = True)
	weight = models.CharField(max_length = 5 , null = True , blank = True)
	identification_mark = models.CharField(max_length = 15 , null = True , blank = True)
	blood_group = models.CharField(max_length = 4 , null = True , blank = True)
	marriage = models.CharField(max_length = 3 , null = True , blank = True)
	marriage_date = models.CharField(max_length = 15 , null = True , blank = True)
	nation = models.CharField(max_length = 5 , null = True , blank = True)




	def __str__(self):
		return f'{self.user.username}'

class Abm(models.Model):
	user = models.OneToOneField(User , on_delete = models.CASCADE , primary_key = True)
	area = models.CharField(max_length = 15 , null = True , blank = True)

	def __str__(self):
		return f'{self.user.username}'

class Rbm(models.Model):
	user = models.OneToOneField(User , on_delete = models.CASCADE , primary_key = True)
	region = models.CharField(max_length = 15 , null = True , blank = True)

	def __str__(self):
		return f'{self.user.username}'

class Zbm(models.Model):
	user = models.OneToOneField(User , on_delete = models.CASCADE , primary_key = True)
	zone = models.CharField(max_length = 15 , null = True , blank = True)

	def __str__(self):
		return f'{self.user.username}'


class Admin(models.Model):
	user = models.OneToOneField(User , on_delete = models.CASCADE , primary_key = True)
	company = models.CharField(max_length = 15 , null = True , blank = True)

	def __str__(self):
		return f'{self.user.username}'








