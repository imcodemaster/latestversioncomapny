from django.urls import path
from . import  views

urlpatterns=[
     path('register/',views.register, name='register'),
     path('se_register/',views.se_register.as_view(), name='se_register'),
     path('abm_register/',views.abm_register.as_view(), name='abm_register'),
     path('rbm_register/',views.rbm_register.as_view(), name='rbm_register'),
     path('zbm_register/',views.zbm_register.as_view(), name='zbm_register'),
     path('login/',views.login_request, name='login'),
     path('logout/',views.logout_view, name='logout'),
     path('profile/',views.profile, name='profile'),
]