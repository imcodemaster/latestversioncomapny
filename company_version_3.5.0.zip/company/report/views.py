from django.shortcuts import render
from django.views.generic import ListView, DetailView, CreateView,UpdateView,DeleteView
from django.shortcuts import get_object_or_404
from .models import * 
from django.urls import reverse_lazy 

# Create your views here.

def home (request):
	return render(request, 'report/admin.html')

class DrVisitView(CreateView):
	model = Dr_Visit
	fields = ['user','dr_name',
	'city' , 'dr_speciality' , 'month' ,
	 'business' ] #describe the field need to create 
	success_url = reverse_lazy('home')

class DailyplanView(CreateView):
	model = Daily_plan
	fields = ['day', 'user' , ] #describe the field need to create 
	success_url = reverse_lazy('home')

class DrvisitreportView(CreateView):
	model = Dr_visit_report
	fields = ['dr_name', 
	'user' , 'city', 
	'place', 'dr_speciality'] #describe the field need to create 
	success_url = reverse_lazy('home')

class ExpensesView(CreateView):
	model = Expenses
	fields = ['working_place', 'user' , 
	'calls_made', 
	'chemist_meeting',
	 'travelling_from', 'travelling_to' , 
	 'distance_travelled' , 'total_appointment' , 
	 'daily_allowance' ,'telephone_internet_expenses' , 'total'] #describe the field need to create 
	success_url = reverse_lazy('home')

class DailyworkingreportView(CreateView):
	model = DailyWorkingReport
	fields = ['dr_name', 'user' , 
	'meeting_place',
	 'prescrebtionBrand',
	  'dr_speciality', 'user_WorkingPlace', 
	  'current_month_business',
	  'Daily_business_outcomes'] #describe the field need to create 
	success_url = reverse_lazy('home')


class ChemistcallreportView(CreateView):
	model = chemist_call_report
	fields = ['chemist_name', 'user' ,
	'business_outcomes_chemist_visit'] #describe the field need to create 
	success_url = reverse_lazy('home')


class DaysummaryreportView(CreateView):
	model = day_summary
	fields = ['user', 'total_calls' ,
	 'business_outcomes_of_total_calls',
	  'total_chemist_meeting',
	   'business_outcomes_of_total_metting', 'delayed_submission'] #describe the field need to create 
	success_url = reverse_lazy('home')



class RcpadetailsView(CreateView):
	model = RCPA_details
	fields = ['brand_name', 'user' ,
	 'competitor_name1', 
	 'competitor_name2', 'competitor_name3' , 'competitor_name4', 'competitor_name5' ,
	  'competitor_name6', 'competitor_name7'] #describe the field need to create 
	success_url = reverse_lazy('home')



class DoctorvisitView(CreateView):
	model = doctor_visit_report
	fields = ['doctor_name', 'user' , 'city',
	 'month', 'dr_speciality'] #describe the field need to create 
	success_url = reverse_lazy('home')

class HQView(CreateView):
	model = HQ_List
	fields = ['user','dr_name',
	'city' , 'dr_speciality' , 'place' ,
	 'current_doctor_business', 'current_prescribing_brand',
	  'brand_name1','brand_name2','brand_name3',
	  'brand_name4', 'brand_name5' ] #describe the field need to create 
	success_url = reverse_lazy('home')

class chemistlist(CreateView):
	model = chemistlist
	fields = ['user', 'chemist_name', 'place', 'contact',
	 'POB_Collection_status','ABM_Approach_Status', 'brand_name1', 'brand_name2' ,
	  'brand_name3' ] #describe the field need to create 
	success_url = reverse_lazy('home')