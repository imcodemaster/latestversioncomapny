from . import views
from django.urls import path

from . import views 
from .views import * 

urlpatterns = [
    path('home/', views.home , name = 'report-home' ),
    path('drvisit/', views.DrVisitView.as_view() , name = 'drvisit-report' ),
    path('dailyplan/', views.DailyplanView.as_view() , name = 'dailyplan-report' ),
	path('drvisitreport/', views.DrvisitreportView.as_view() , name = 'drvisitreport-report' ),
	path('expensesreport/', views.ExpensesView.as_view() , name = 'expenses-report' ),
	path('dailyworkingreport/', views.DailyworkingreportView.as_view() , name = 'dailyworkingreport-report' ),
	path('chemistcallreport/', views.ChemistcallreportView.as_view() , name = 'chemistcall-report' ),
	path('daysummaryreport/', views.DaysummaryreportView.as_view() , name = 'daysummary-report' ),
	path('rcpareport/', views.RcpadetailsView.as_view() , name = 'rcpa-report' ),
	path('doctorvisitreport/', views.DoctorvisitView.as_view() , name = 'doctorvisit-report' ),
	path('hqlist/', views.HQView.as_view() , name = 'hq-report' ),
	path('chemistlist/', views.chemistlist.as_view() , name = 'chemist-list' )

]


